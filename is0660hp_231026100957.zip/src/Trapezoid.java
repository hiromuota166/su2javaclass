// 台形の面積を求めるクラス
class Trapezoid extends Shape{
  private int bottom;
  private int width;
  private int height;

  public Trapezoid(int bottom, int width, int height) {
    this.bottom = bottom;
    this.width = width;
    this.height = height;
  }

  @Override
  public double area() {
    return (this.width + this.height) * this.bottom / 2.0;
  }

  @Override
  public String description() {
    return String.format(
      "<Trapezoid: left:%d top:%d width:%d height:%d area:%.2f>",
      this.bottom, this.width, this.height, this.area());
  }
}
