import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Main {
// ウィンドウタイトル
  private static final String TITLE = "2600220060-0 太田啓夢";
  // ウィンドウの位置
  private static final int FRAME_POSX = 10;
  private static final int FRAME_POSY = 10;
  // キャンバスのサイズ
  private static final int CANVAS_WIDTH = 800;
  private static final int CANVAS_HEIGHT = 500;

  public static void main(String... args) {
    var frame = new JFrame();
    // ウィンドウのクローズボタンをクリックした時にアプリケーションを終了する．
    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    // ウィンドウのタイトルの設定
    frame.setTitle(TITLE);
    // ウィンドウの位置の設定
    frame.setLocation(FRAME_POSX, FRAME_POSY);
    var canvas= new CanvasPanel();
    canvas.setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_HEIGHT));
    canvas.setBackground(new Color(255, 255, 255));
    // （略）
    canvas.addShape(new Circle(300, 200, 100));
    canvas.addShape(new Rectangle(100, 100, 200, 200));
    canvas.addShape(new Line(100, 100, 300, 300));
    // （略）
    frame.add(canvas, BorderLayout.CENTER);
    frame.pack();
    frame.setVisible(true);
  }
}