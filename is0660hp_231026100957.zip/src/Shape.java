import java.awt.Graphics;

/**
 * 図形の基底となるクラス
 */
public abstract class Shape {
  /**
   * 図形の面積を返す．
   */
  public abstract double area();

  /**
   * 図形の情報を表す文字列を返す．
   */
  public abstract String description();
  /**
   * 図形の描画する
   */
  public abstract void draw(Graphics g);
}
