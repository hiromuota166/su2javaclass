import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class CanvasPanel extends JPanel {
  private List<Shape> shapes = new ArrayList<>();
  private Color color = new Color(0, 0, 0, 64);

  public void addShape(Shape shape) {
    this.shapes.add(shape);
    this.repaint();
  }
  
  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
      g.setColor(this.color);
      for (Shape shape : this.shapes) {
      shape.draw(g);
    }
  }
}