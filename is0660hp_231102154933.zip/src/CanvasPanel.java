import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;

public class CanvasPanel extends JPanel {
  private List<Shape> shapes = new ArrayList<>();
  private Color color = new Color(0, 0, 0, 64);
  private ShapeFactory factory;

  public void addShape(Shape shape) {
    this.shapes.add(shape);
    this.repaint();
  }

  public CanvasPanel() {
    var listener = new CanvasListener(this);
    this.addMouseMotionListener(listener);
    this.addMouseListener(listener);
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(this.color);
    for (Shape shape : this.shapes) {
      shape.draw(g);
    }
  }

  public ShapeFactory getFactory() {
    return this.factory;
  }

  public void setFactory(ShapeFactory factory) {
    this.factory = factory;
  }

  public void resizeShape(Shape shape, int x, int y) {
    shape.resize(x, y);
    this.repaint();
  }
}
