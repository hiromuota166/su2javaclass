import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * キャンバスのマウスリスナー
 */
public class CanvasListener extends MouseAdapter {
  // 対応するキャンバス
  private CanvasPanel canvas;
  // 作成中の図形
  private Shape shape;

  /**
   * コンストラクタ 対応するキャンバスを引数にとる．
   */
  public CanvasListener(CanvasPanel canvas) {
    this.canvas = canvas;
  }

  @Override
  public void mousePressed(MouseEvent me) {
    ShapeFactory factory = this.canvas.getFactory();
    int x = me.getX();
    int y = me.getY();
    this.shape = factory.create(x, y);
    this.canvas.addShape(this.shape);
  }

  @Override
  public void mouseDragged(MouseEvent me) {
    int x = me.getX();
    int y = me.getY();
    this.canvas.resizeShape(this.shape, x, y);
  }

  @Override
  public void mouseReleased(MouseEvent me) {
    this.shape = null;
  }
}
