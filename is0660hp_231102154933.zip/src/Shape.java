import java.awt.Graphics;
public abstract class Shape {
  public abstract double area();
  public abstract String description();
  public abstract void draw(Graphics g);
  public abstract void resize(int x, int y);
}
