public abstract class ShapeFactory {
  public abstract Shape create(int x, int y);
}