class Rectangle extends Shape {
  private int left;
  private int top;
  private int width;
  private int height;

  public Rectangle(int left, int top, int width, int height) {
    this.left = left;
    this.top = top;
    this.width = width;
    this.height = height;
  }

  @Override
  public double area() {
    return this.width * this.height;
  }

  @Override
  public String description() {
    return String.format(
        "<Rectangle: left:%d top:%d width:%d height:%d area:%.2f>",
        this.left, this.top, this.width, this.height, this.area());
  }
}