// 台形の面積を求めるクラス
class Trapezoid extends Shape{
  private int left;
  private int top;
  private int width;
  private int height;

  public Trapezoid(int left, int top, int width, int height) {
    this.left = left;
    this.top = top;
    this.width = width;
    this.height = height;
  }

  @Override
  public double area() {
    return (this.width + this.height) * this.height / 2.0;
  }

  @Override
  public String description() {
    return String.format(
      "<Trapezoid: left:%d top:%d width:%d height:%d area:%.2f>",
      this.left, this.top, this.width, this.height, this.area());
  }
}
