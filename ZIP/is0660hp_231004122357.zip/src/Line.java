public class Line {
  private int x1;
  private int y1;
  private int x2;
  private int y2;

  public Line(int x1, int y1, int x2, int y2) {
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
  }

  public double area() {
    int dx = this.x2 - this.x1;
    int dy = this.y2 - this.y1;
    return Math.sqrt(dx * dx + dy * dy);
  }

  public String description() {
    return String.format("<Line: start:(%d, %d) end:(%d, %d) area:%" + ".2f>",
    this.x1, this.y1, this.x2, this.y2, this.area());
  }
}