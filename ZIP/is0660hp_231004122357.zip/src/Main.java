/**
 * エントリーポイントとなるクラス
 */
public class Main {
  public static void main(String... args) {
    System.out.println("2600220060-0 太田 啓夢");

    Circle c1 = new Circle(200, 300, 100);
    System.out.println(c1.description());

    Rectangle rect1 = new Rectangle(100, 200, 300, 400);
    System.out.println(rect1.description());

    Line line1 = new Line(100, 200, 300, 400);
    System.out.println(line1.description());

    System.out.printf("Total Area: %.2f%n",
    c1.area() + rect1.area() + line1.area());
  }
}