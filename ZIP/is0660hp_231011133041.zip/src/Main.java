import java.util.ArrayList;

public class Main {
  public static void main(String... args) {
    System.out.println("2600220060-0 太田 啓夢");

    ArrayList<Shape> shapes = new ArrayList<>();

    shapes.add(new Circle(200, 300, 100));
    shapes.add(new Rectangle(100, 200, 300, 400));
    shapes.add(new Line(100, 200, 300, 400));
    double total = 0.0;
    for (Shape shape : shapes) {
      System.out.println(shape.description());
      total = total + shape.area();
    }
    System.out.printf("*** Total area:%.2f ***%n",total);
  }
}
