// public class Oval extends Shape {
// // インスタンス変数の定義を行う
// private int x;
// private int y;
// private int width;
// private int height;
// // コンストラクタを定義する
// public Oval(int x, int y, int width, int height) {
// this.x = x;
// this.y = y;
// this.width = width;
// this.height = height;
// }
// @Override
// public double area() {

// }
// @Override
// public String description() {
// // （略）
// }
// }
