class Circle extends Shape {
  private int x;
  private int y;
  private int r;

  public Circle(int x, int y, int r) {
    this.x = x;
    this.y = y;
    this.r = r;
  }

  @Override
  public double area() {
    return Math.PI * this.r * this.r;
  }
  @Override
  public String description() {
    return String.format("<Circle: center:(%d, %d) r:%d area:%.2f>",
        this.x, this.y, this.r, this.area());
  }
}