// 正方形の面積を求めるクラス
class Square extends Shape {
  private int left;
  private int top;
  private int width;

  public Square(int left, int top, int width) {
    this.left = left;
    this.top = top;
    this.width = width;
  }

  @Override
  public double area() {
    return this.width * this.width;
  }
  @Override
  public String description() {
    return String.format(
        "<Square: left:%d top:%d width:%d area:%.2f>",
        this.left, this.top, this.width, this.area());
  }
}