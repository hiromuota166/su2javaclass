// 正三角形の面積を求めるクラス
class EquilateralTriangle extends Shape {
  private int left;
  private int top;
  private int width;

  public EquilateralTriangle(int left, int top, int width) {
    this.left = left;
    this.top = top;
    this.width = width;
  }

  @Override
  public double area() {
    return this.width * this.width * Math.sqrt(3) / 4.0;
  }
  @Override
  public String description() {
    return String.format(
        "<EquilateralTriangle: left:%d top:%d width:%d area:%.2f>",
        this.left, this.top, this.width, this.area());
  }
}
