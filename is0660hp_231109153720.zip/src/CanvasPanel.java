import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JPanel;
import java.util.ArrayDeque;
import java.util.Deque;

public class CanvasPanel extends JPanel {
  private List<Shape> shapes = new ArrayList<>();
  private Color color = new Color(0, 0, 0, 64);
  private ShapeFactory factory;
  private Deque<Command> commandHistory = new ArrayDeque<>();
  private Deque<Command> undoHistory = new ArrayDeque<>();

  public CanvasPanel() {
    var listener = new CanvasListener(this);
    this.addMouseMotionListener(listener);
    this.addMouseListener(listener);
  }

  public void addShape(Shape shape) {
    this.shapes.add(shape);
    this.repaint();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(this.color);
    for (Shape shape : this.shapes) {
      shape.draw(g);
    }
  }

  public void clearShapes() {
    this.shapes.clear();
    this.repaint();
  }

  public ShapeFactory getFactory() {
    return this.factory;
  }

  public void setFactory(ShapeFactory factory) {
    this.factory = factory;
  }

  public void resizeShape(Shape shape, int x, int y) {
    shape.resize(x, y);
    this.repaint();
  }

  public List<Shape> getShapes() {
    return this.shapes;
  }

  public void removeShape(Shape shape) {
    this.shapes.remove(shape);
    this.repaint();
  }

  public void execute(Command command) {
    command.execute();
    this.commandHistory.push(command);
    this.undoHistory.clear();
  }

  public void undo() {
    if (!this.commandHistory.isEmpty()) {
    Command command = this.commandHistory.pop();
    command.undo();
    this.undoHistory.push(command);
    }
  }

  public void redo() {
    if (!this.undoHistory.isEmpty()) {
    Command command = this.undoHistory.pop();
    command.execute();
    this.commandHistory.push(command);
    }
  }
}
