@FunctionalInterface
public interface UIObserver {
  void stateChanged();
}
